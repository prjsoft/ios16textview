//
//  ViewController.swift
//  textview
//
//  Created by Алексей Шечков on 31.07.2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtView: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        txtView.text = """
        txtView.text = txtView.text + "he red-headed myzomela (Myzomela erythrocephala) is a bird of the honeyeater family, Meliphagidae. One of two subspecies, M. e. erythrocephala, is distributed around the
        
        txtView.text = txtView.text + "
        he red-headed myzomela (Myzomela erythrocephala) is a bird of the honeyeater family, Meliphagidae. One of two subspecies, M. e. erythrocephala, is distributed around the
        
        txtView.text = txtView.text + "he red-headed myzomela (Myzomela erythrocephala) is a bird of the honeyeater family, Meliphagidae. One of two subspecies, M. e. erythrocephala, is distributed around the
        
        txtView.text = txtView.text + "he red-headed myzomela (Myzomela erythrocephala) is a bird of the honeyeater family, Meliphagidae. One of two subspecies, M. e. erythrocephala, is distributed around the
        
        txtView.text = txtView.text + "he red-headed myzomela (Myzomela erythrocephala) is a bird of the honeyeater family, Meliphagidae. One of two subspecies, M. e. erythrocephala, is distributed around the
        
                txtView.text = txtView.text + "he red-headed myzomela (Myzomela erythrocephala) is a bird of the honeyeater family, Meliphagidae. One of two subspecies, M. e. erythrocephala, is distributed around the
                
                txtView.text = txtView.text + "
                he red-headed myzomela (Myzomela erythrocephala) is a bird of the honeyeater family, Meliphagidae. One of two subspecies, M. e. erythrocephala, is distributed around the
                
                txtView.text = txtView.text + "he red-headed myzomela (Myzomela erythrocephala) is a bird of the honeyeater family, Meliphagidae. One of two subspecies, M. e. erythrocephala, is distributed around the
                
                txtView.text = txtView.text + "he red-headed myzomela (Myzomela erythrocephala) is a bird of the honeyeater family, Meliphagidae. One of two subspecies, M. e. erythrocephala, is distributed around the
                
                txtView.text = txtView.text + "he red-headed myzomela (Myzomela erythrocephala) is a bird of the honeyeater family, Meliphagidae. One of two subspecies, M. e. erythrocephala, is distributed around the+
        
                          txtView.text = txtView.text + "he red-headed myzomela (Myzomela erythrocephala) is a bird of the honeyeater family, Meliphagidae. One of two subspecies, M. e. erythrocephala, is distributed around the
                          
                          txtView.text = txtView.text + "
                          he red-headed myzomela (Myzomela erythrocephala) is a bird of the honeyeater family, Meliphagidae. One of two subspecies, M. e. erythrocephala, is distributed around the
                          
                          txtView.text = txtView.text + "he red-headed myzomela (Myzomela erythrocephala) is a bird of the honeyeater family, Meliphagidae. One of two subspecies, M. e. erythrocephala, is distributed around the
                          
                          txtView.text = txtView.text + "he red-headed myzomela (Myzomela erythrocephala) is a bird of the honeyeater family, Meliphagidae. One of two subspecies, M. e. erythrocephala, is distributed around the
                          
                          txtView.text = txtView.text + "he red-headed myzomela (Myzomela erythrocephala) is a bird of the honeyeater family, Meliphagidae. One of two subspecies, M. e. erythrocephala, is distributed around the+
                  

        """
        // Do any additional setup after loading the view.
    }


    @IBAction func lostFocus(_ sender: UIButton) {
        txtView.resignFirstResponder()
    }
    @IBAction func pressButton(_ sender: UIButton) {
        
        addText()

    }
    
    func addText(){
        txtView.text = txtView.text + "a"

        
    }
}

